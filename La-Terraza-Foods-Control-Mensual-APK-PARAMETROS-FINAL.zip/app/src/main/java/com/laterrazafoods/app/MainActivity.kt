package com.laterrazafoods.app

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

data class Movement(
    val id: Long,
    val type: String,
    val date: String,
    val name: String,
    val amount: Long,
    val taxable: Boolean,
    val category: String,
    val payment: String
)

class MainActivity : Activity() {
    private val items = mutableListOf<Movement>()
    private lateinit var prefs: android.content.SharedPreferences
    private val currency = NumberFormat.getCurrencyInstance(Locale("es", "CL"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ltf_data", Context.MODE_PRIVATE)
        currency.maximumFractionDigits = 0
        load()
        home()
    }

    private fun today(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun money(value: Long): String = currency.format(value)

    private fun iva(amount: Long, taxable: Boolean): Long =
        if (taxable) amount * 19 / 119 else 0

    private fun load() {
        val raw = prefs.getString("movements", "") ?: return
        if (raw.isBlank()) return
        raw.split("\n").forEach { line ->
            val p = line.split("|")
            if (p.size == 8) {
                runCatching {
                    items.add(
                        Movement(
                            p[0].toLong(), p[1], p[2], p[3],
                            p[4].toLong(), p[5] == "1", p[6], p[7]
                        )
                    )
                }
            }
        }
    }

    private fun save() {
        val raw = items.joinToString("\n") {
            listOf(
                it.id, it.type, it.date, it.name.replace("|", " "),
                it.amount, if (it.taxable) "1" else "0",
                it.category.replace("|", " "), it.payment.replace("|", " ")
            ).joinToString("|")
        }
        prefs.edit().putString("movements", raw).apply()
    }

    private fun baseLayout(): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
        }

    private fun title(text: String): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 26f
            setTextColor(Color.rgb(25, 25, 25))
            setPadding(0, 0, 0, 16)
        }

    private fun button(text: String): Button =
        Button(this).apply { this.text = text }

    private fun home() {
        val root = baseLayout()
        root.addView(title("La Terraza Foods"))
        root.addView(TextView(this).apply {
            text = "Control Mensual · IVA 19% · PPM 1%"
            textSize = 15f
            setPadding(0, 0, 0, 18)
        })

        val summary = TextView(this).apply { textSize = 17f }
        root.addView(summary)

        val date = EditText(this).apply {
            hint = "Fecha (AAAA-MM-DD)"
            setText(today())
            inputType = 1
        }
        root.addView(date)

        fun refresh() {
            val day = date.text.toString()
            val daily = items.filter { it.date == day }
            val sales = daily.filter { it.type == "VENTA" }.sumOf { it.amount }
            val purchases = daily.filter { it.type == "COMPRA" }.sumOf { it.amount }
            val debit = daily.filter { it.type == "VENTA" }.sumOf { iva(it.amount, it.taxable) }
            val credit = daily.filter { it.type == "COMPRA" }.sumOf { iva(it.amount, it.taxable) }
            val diff = debit - credit
            val ppm = daily.filter { it.type == "VENTA" && it.taxable }.sumOf { it.amount } * 1 / 100
            summary.text = """
                RESUMEN DIARIO

                Ventas: ${money(sales)}
                Compras: ${money(purchases)}
                Resultado: ${money(sales - purchases)}

                IVA débito: ${money(debit)}
                IVA crédito: ${money(credit)}
                ${if (diff >= 0) "IVA a pagar: ${money(diff)}" else "Remanente IVA: ${money(-diff)}"}

                PPM 1%: ${money(ppm)}
                Efectivo: ${money(daily.filter { it.type == "VENTA" && it.payment == "Efectivo" }.sumOf { it.amount })}
                Tarjetas: ${money(daily.filter { it.type == "VENTA" && (it.payment == "Tarjeta débito" || it.payment == "Tarjeta crédito") }.sumOf { it.amount })}
            """.trimIndent()
        }
        date.setOnFocusChangeListener { _, _ -> refresh() }
        refresh()

        val addPurchase = button("🛒 Registrar compra")
        val addSale = button("💰 Registrar venta")
        val history = button("📋 Historial")
        root.addView(addPurchase)
        root.addView(addSale)
        root.addView(history)

        addPurchase.setOnClickListener { form("COMPRA") }
        addSale.setOnClickListener { form("VENTA") }
        history.setOnClickListener { history() }

        setContentView(root)
    }

    private fun form(type: String) {
        val root = baseLayout()
        root.addView(title(if (type == "VENTA") "Registrar venta" else "Registrar compra"))

        fun field(hint: String) = EditText(this).apply {
            this.hint = hint
            setPadding(10, 8, 10, 8)
        }

        val date = field("Fecha (AAAA-MM-DD)").apply { setText(today()) }
        val name = field(if (type == "VENTA") "Cliente" else "Proveedor")
        val amount = field("Monto total").apply { inputType = 2 }
        val category = field("Categoría")
        val taxable = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Afecto a IVA", "Sin IVA")
            )
        }
        val payment = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Efectivo", "Tarjeta débito", "Tarjeta crédito", "Transferencia", "Otro")
            )
        }

        root.addView(date)
        root.addView(name)
        root.addView(amount)
        root.addView(category)
        root.addView(TextView(this).apply { text = "IVA" })
        root.addView(taxable)
        root.addView(TextView(this).apply { text = "Forma de pago" })
        root.addView(payment)

        val calc = TextView(this)
        root.addView(calc)
        amount.setOnKeyListener { _, _, _ ->
            val n = amount.text.toString().toLongOrNull() ?: 0
            calc.text = if (taxable.selectedItemPosition == 0 && n > 0)
                "Neto: ${money(n - n * 19 / 119)} · IVA: ${money(n * 19 / 119)}"
            else ""
            false
        }

        val saveButton = button("Guardar")
        val back = button("Volver")
        root.addView(saveButton)
        root.addView(back)

        saveButton.setOnClickListener {
            val n = amount.text.toString().toLongOrNull() ?: 0
            if (date.text.isBlank() || name.text.isBlank() || n <= 0) {
                Toast.makeText(this, "Completa los datos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            items.add(
                Movement(
                    System.currentTimeMillis(), type, date.text.toString(),
                    name.text.toString(), n, taxable.selectedItemPosition == 0,
                    category.text.toString().ifBlank { "Otros" },
                    payment.selectedItem.toString()
                )
            )
            save()
            Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show()
            home()
        }
        back.setOnClickListener { home() }

        setContentView(root)
    }

    private fun history() {
        val root = baseLayout()
        root.addView(title("Historial"))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No hay movimientos registrados."
                textSize = 16f
            })
        }

        items.sortedByDescending { it.id }.forEach { item ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, 10, 0, 10)
            }
            box.addView(TextView(this).apply {
                text = "${item.type} · ${item.date}\n${item.name}\n${money(item.amount)} · IVA ${money(iva(item.amount, item.taxable))}\n${item.payment}"
                textSize = 16f
            })
            val del = button("Eliminar")
            del.setOnClickListener {
                items.removeIf { it.id == item.id }
                save()
                history()
            }
            box.addView(del)
            list.addView(box)
        }

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val back = button("Volver")
        back.setOnClickListener { home() }
        root.addView(back)
        setContentView(root)
    }
}
