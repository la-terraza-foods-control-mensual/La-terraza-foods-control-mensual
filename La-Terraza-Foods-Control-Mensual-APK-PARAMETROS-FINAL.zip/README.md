# La Terraza Foods, Control Mensual

Proyecto Android nativo preparado para generar una APK de prueba.

## Funciones previstas
- Compras con IVA / sin IVA
- Ventas
- Ventas en efectivo, débito, crédito y transferencia
- IVA débito fiscal
- IVA crédito fiscal
- IVA a pagar o remanente
- PPM fijo 1%
- Resumen diario y mensual
- Historial
- Almacenamiento local
- Identidad visual basada en el logo de La Terraza Foods

## Compilación en Codespaces
En la terminal, usar Java 17 y ejecutar:

    gradle assembleDebug

El APK se genera en:

    app/build/outputs/apk/debug/app-debug.apk

También incluye `codemagic.yaml` para compilación online con Codemagic.
